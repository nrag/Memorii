# Proposed Capability Baseline Approval Authority

Status: proposed and nonnormative. This closes no implementation or acceptance
requirement. It is the determinate authority design required by SIA 1209-1269
before an acceptance-only verifier can produce the six-field
`VerifiedCapabilityBaselineApproval`.

## Boundary and construction order

The authority is acceptance-only and has no imports from production semantic,
policy, tool, persistence, or CTV helpers. It reads public serialized envelopes
and protected acceptance configuration. The verifier receives release bytes,
baseline bytes, and caller-supplied evaluation time. It never receives a
snapshot, key, lifecycle record, pointer, checkpoint, profile, limit, or
provider selection from the CLI.

Construction is acyclic:

```text
protected anchor + protected bootstrap ceilings
  -> signed issuance-trust snapshot -> immutable signed release
  -> signed lifecycle/key-state records -> unsigned replay-derived pointer
  -> signed current-status checkpoint -> verified result
```

The issuance snapshot contains only static issuance trust and signed effective
limits. It never hashes status. A status checkpoint, supplied solely by the
anchor-selected protected current-status provider, names the replayed lifecycle
and key-state heads. Therefore an old, still-unexpired issuance snapshot or a
self-consistent old prefix cannot prove currentness.

## Closed schemas and byte rules

All schemas below are proposed CTV roots with no omitted/default fields. Every
digest is lowercase SHA-256 hex; every `signature` is canonical RFC 4648 padded
base64 whose decoded value is exactly 64 bytes; every public key is exactly 32
raw Ed25519 bytes. The signature profile is exactly
`memorii.acceptance.ed25519.rfc8032.v1`: RFC 8032 PureEdDSA, SHA-512, empty
context, no prehash. The profile does not choose a real authority or key.
Protected external configuration selects anchor key bytes and provider identity.

Profile v3 inherits v2/SIA 2783 encoded UTF-8 JSON-string-byte map-key order.
It does not use Unicode-scalar order. Numeric certificate/body maps have fixed
ASCII keys and require a vector proving equivalence for those declared keys;
an escaped-Unicode vector proves the general encoder rule. Existing v1/v2
artifacts remain replayable under their original frozen bindings.

```text
BootstrapLimits := {
  max_release_bytes, max_baseline_bytes, max_snapshot_bytes,
  max_lifecycle_record_bytes, max_key_state_record_bytes,
  max_current_checkpoint_bytes, max_ctv_depth, max_ctv_nodes,
  max_string_bytes, max_integer_digits
}
EffectiveVerifierLimits := same fields, limits_digest
CapabilityBaselineApprovalSigningKey := {
  key_reference, approver_subject_id, signature_profile_id, public_key_bytes,
  public_key_fingerprint, valid_from, valid_until: DateTime|null,
  allowed_purposes, key_static_digest
}
CapabilityBaselineApprovalKeyStateRecord := {
  key_reference, state: active|retired|revoked|compromised,
  key_state_sequence, predecessor_key_state_digest: Digest|null, recorded_at,
  issuance_trust_snapshot_digest, key_state_digest, signing_key_coordinate,
  signature
}
CapabilityBaselineApprovalIssuanceTrustSnapshot := {
  authority_id, snapshot_sequence, predecessor_snapshot_digest: Digest|null,
  keys, effective_limits, issuance_trust_snapshot_digest,
  signing_key_coordinate, signature
}
CapabilityBaselineApprovalRelease := SIA 1209-1232 exact fields, including
  acceptance_release_epoch, acceptance_release_sequence, release_digest,
  signature
CapabilityBaselineApprovalLifecycleRecord := {
  target_approved_capability_baseline_artifact_digest, subject_release_digest,
  transition: activate_genesis|activate_successor|revoke|compromise,
  record_sequence, effective_lifecycle_epoch, effective_lifecycle_sequence,
  predecessor_record_digest: Digest|null,
  prior_active_release_digest: Digest|null,
  successor_release_digest: Digest|null, revoked_at: DateTime|null,
  compromise_effective_at: DateTime|null, issuance_trust_snapshot_digest,
  lifecycle_record_digest, signing_key_coordinate, signature
}
ActiveCapabilityBaselineApproval := {
  target_approved_capability_baseline_artifact_digest, release_digest,
  acceptance_release_epoch, acceptance_release_sequence,
  lifecycle_head_digest, active_record_digest, pointer_digest
}
CapabilityBaselineApprovalStatusCheckpoint := {
  target_approved_capability_baseline_artifact_digest, status_generation,
  lifecycle_head_digest, lifecycle_head_sequence,
  current_key_state_head_digest, current_key_state_sequence,
  active_pointer_digest: Digest|null, active_release_epoch: Integer|null,
  active_release_sequence: Integer|null, observed_at, checkpoint_digest,
  status_signer_coordinate, signature
}
CapabilityBaselineApprovalStatusSignerCoordinate := {
  key_reference, signature_profile_id:
  "memorii.acceptance.ed25519.rfc8032.v1",
  purpose: "semantic_ingestion_capability_baseline_current_status",
  public_key_fingerprint
}
VerifiedCapabilityBaselineApproval := {
  release_digest, target_approved_capability_baseline_artifact_digest,
  acceptance_authority_snapshot_digest, acceptance_release_epoch, verified_at,
  verification_digest
}
```

`active_pointer_digest`, `active_release_epoch`, and
`active_release_sequence` are required-nullable as a group: all are null iff
replay has no active release; otherwise all are nonnull and exactly equal the
pointer. No other partial state is legal. `predecessor_*` is null only in a
genesis record. Lifecycle terminal timestamps are nonnull only for their
matching transition. Static release issuance coordinates are immutable and do
not change when a later lifecycle record changes effective state.

Bootstrap limits are protected, positive, held configuration used to cap input
bytes and CTV depth/nodes/string/integer size before decoding any untrusted
artifact. Only after anchor and snapshot verification may the signed effective
limits be used, and each field must be positive and less than or equal to its
bootstrap counterpart. Signed limits can narrow parsing; they cannot enlarge
it.

## Digests, signatures, and currentness

Every body digest is `SHA-256(LP(domain, complete-binding, unsigned-canonical-
content))`, with domain names ending in `:v1\0`. `unsigned-canonical-content`
omits only the body digest and `signature` fields. Release omits exactly
`release_digest` and `signature`. The exact approval signature preimage is the
CTV body `{approval_purpose, complete_release_binding, recomputed_release_digest,
unsigned_release_canonical_content: bytes, complete_signing_key_coordinate}`.
Snapshot, key-state, lifecycle, and checkpoint use the identical five-element
preimage shape with their literal purpose, complete body binding, recomputed
body digest, exact unsigned content bytes, and complete selected signer
coordinate. The checkpoint purpose is the literal status purpose in the signer
coordinate. No PEM parsing, inferred key, fallback profile, or ambient current
time exists.

The active pointer is **unsigned** replay output. Its digest covers every listed
pointer field. It becomes authoritative only because the signed checkpoint
includes its digest and all three active coordinates. The checkpoint also
includes the complete current key-state head digest and sequence. The verifier
replays the contiguous signed key-state chain from genesis to that head and
requires the selected approval key to remain `active`; a later revoke or
compromise therefore blocks an otherwise valid historical release.

The checkpoint signer coordinate is anchored configuration, not caller input.
The verifier requires exact key reference, profile, purpose and public-key
fingerprint before verifying its full preimage. Checkpoint generation is
strictly increasing in the protected provider and it binds the exact replayed
lifecycle head digest/sequence, key-state head digest/sequence, and pointer
coordinate group.

## Lifecycle state table

| Transition | Required prior state | Record coordinates | Pointer output |
| --- | --- | --- | --- |
| `activate_genesis` | no record and no active release | record seq 1; effective epoch/seq 1; all prior/successor/terminal fields null | nonnull pointer for subject |
| `activate_successor` | one active predecessor | contiguous record seq; effective epoch/seq each increment one; `prior_active_release_digest` names predecessor; `successor_release_digest` equals subject | pointer atomically changes to subject |
| `revoke` | subject exists, active or terminal | contiguous record seq and effective sequence increment one; `revoked_at` nonnull; successor null | null iff subject was active, otherwise unchanged |
| `compromise` | subject exists, active or terminal | contiguous record seq and effective sequence increment one; compromise and revocation times nonnull | null iff subject was active, otherwise unchanged |

There is no `supersede` transition. Successor activation is the only atomic
operation that terminates the prior active release and installs the successor.
No revoke or compromise can be followed by activation of that release. A
release's immutable issuance epoch/sequence remains the fields in its signed
release bytes; `effective_lifecycle_epoch` and `effective_lifecycle_sequence`
belong only to lifecycle records and checkpoints.

## Baseline and composition binding

The baseline is independently decoded as `ApprovedCapabilityBaselineArtifact`.
The verifier recomputes its digest and compares the release target and each
capability, contract, dependency, coverage, gate, monitoring, and unsupported-
cells coordinate exactly. Under SIA 3921-3930 its stable artifact content omits
only `deployment_authorization_digest` and is approval/authorization-neutral.
Approval signs that stable baseline digest; later deployment authorization signs
the target digest plus the verified release digest and then attaches its own
authorization digest. This avoids a cycle.

The independent numeric coverage/frame owner subsequently constructs the whole
`PreverifiedNumericCertificationContext` from the approved baseline coordinates
and requires exact equality before statistical evaluation. This proposal neither
copies numeric policy nor supplies numeric defaults.

The future CLI is protected-loader-only: `python -m
acceptance.capability_baseline_approval verify RELEASE BASELINE --evaluation-time
RFC3339 --output PATH`. It has no `--snapshot`, `--checkpoint`, `--pointer`,
`--key`, `--limits`, or authority-provider argument. The later composition proof
is acceptance verifier -> verified release digest -> deployment authorization
issuance request -> signed authorization -> production read-only verifier. It
must add a real non-test caller to `production_entrypoint_bindings`; none exists
in this proposed-only slice.

## Required promotion and evidence

Promotion freezes the architecture declaration, profile-v3 encoder/checker,
complete root inventory and binding/digest-exclusion declarations before code:
release; release preimage; signing key; key-state record and preimage; snapshot
and preimage; effective limits; lifecycle record and preimage; unsigned pointer;
status checkpoint and preimage; signer coordinate; trust anchor; verified
result; approved baseline; and the approved statistical numeric roots. The
canonical compiler and independent checker must both derive the new inventory,
registry, structural manifest, and accepted/rejected vectors. No release may
supply a binding digest manually.

`authority_feasibility.py` is a bounded, independent, nonproduction model. Its
seven focused tests use re-signed trusted fixture bodies to prove the proposed
DAG, current-pointer rejection, semantic checkpoint-signer and active-nullability
rejection, all-null terminal rejection, current key-head revoke/retire/compromise/
revival/rotation behavior, pointer-digest recomputation, immutable issuance
versus effective lifecycle counters, legal genesis/successor/revoke fields,
encoded JSON-string-byte ordering including nested values, and bootstrap/effective
limit behavior. They do not prove canonical CTV decoding, the complete verifier,
all lifecycle transitions, baseline transport, or production composition.

Next action: root freezes these corrected proposal files and submits the
candidate to the standard design-review cohort. No canonical promotion or
runtime implementation follows from this proposal alone.
