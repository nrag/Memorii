# Capability Baseline Acceptance Authority

- Work ID: acceptance-authority
- Work type: design
- Status: proposed; Round 1 remediation complete pending re-review
- Parent WorkPlan: ../engineering-closure/implementation.plan.md
- Related WorkPlans: ../engineering-closure/milestones/03-independent-statistical-evaluator.plan.md; ../statistical-acceptance/design.plan.md
- Canonical input: `docs/design/semantic_ingestion_architecture.md` SIA 1209-1269, 2783-2786, and 3921-3930

## Objective and boundary

Specify an acceptance-only, fail-closed authority that can later derive SIA's
six-field `VerifiedCapabilityBaselineApproval` from exact serialized release,
baseline, issuance-trust, lifecycle/key-state, current-checkpoint, and caller
sourced evaluation-time evidence. It does not select an operational key,
quality threshold, policy value, numeric result, or production authority.

No runtime, registry, CTV compiler, canonical architecture, CLI, or production
entrypoint changes are in scope. Acceptance remains outside the installed
production wheel. Real signatures are deferred, but unsigned data is never an
accepted substitute.

## Round 1 remediation record

The proposal now makes all seven confirmed review corrections determinate:

1. The protected signed current-status checkpoint binds current key-state head
digest/sequence; replay is contiguous and a current revoked/compromised key
rejects an old unexpired prefix.
2. Pointer digest, active release epoch, and active release sequence are all
required-nullable and enforce an all-null/all-present invariant.
3. The checkpoint carries an exact anchored status signer coordinate, literal
purpose, profile, fingerprint, and complete signature preimage. Pointers are
unsigned replay results authenticated only through the checkpoint.
4. Releases retain immutable static issuance coordinates; lifecycle records and
checkpoints own separate effective coordinates and a four-row transition table.
5. CTV profile v3 preserves SIA encoded UTF-8 JSON-string-byte key ordering.
The proposed vector set includes fixed ASCII numeric-map equivalence and an
escaped-Unicode ordering case.
6. Protected bootstrap decode ceilings bind raw input before parsing; signed
effective limits are verified later and can only narrow the ceilings.
7. Evidence correctly names the local seven-test feasibility model and its limits.

The status provider is protected-loader-only and atomically supplies the signed
checkpoint. CLI inputs cannot select snapshots, keys, heads, pointers, limits,
or providers. The baseline artifact digest keeps SIA 3921-3930's only exclusion,
`deployment_authorization_digest`, with approval/authorization-neutral content.

## Determinate implementation sequence after approval

1. Freeze the exact profile-v3 root inventory, field exclusion policies, and
schema bindings in the architecture and canonical compiler source.
2. Implement matching profile-v3 compiler and independent checker, then produce
accepted/rejected bodies, preimages, signatures, Unicode-order, bootstrap-limit,
replay, baseline-substitution, and lifecycle vectors.
3. Implement acceptance-owned decoder/verifier with protected anchor, bootstrap
limits, issuance loader, lifecycle repository, and atomic current-status
provider; prove all failure cases fail closed.
4. Implement protected-loader-only acceptance CLI and verify it uses canonical
owner code rather than fixtures.
5. Compose verified release digest with deployment-authorization issuance, add
that non-test caller to `production_entrypoint_bindings`, and prove production
reaches the canonical owner with the required authority.
6. Separately promote the independent numeric coverage/frame construction and
prove exact `PreverifiedNumericCertificationContext` equality before evaluator
use.

## Evidence and next action

The local feasibility suite is not canonical/runtime evidence. It is a bounded
proof of the dependency DAG, stale pointer and pointer-digest recomputation,
checkpoint signer/coordinate semantics under trusted re-signing, key-state
rollback/revocation/retirement/compromise/revival/rotation, active nullability,
counter separation, genesis/successor/revoke fields, CTV map ordering, and
bootstrap-limit mechanics. It does not establish full CTV,
production composition, all lifecycle behavior, or R14.

Next action: freeze this remediation as a new candidate and request the
standard three-reviewer design re-review. Do not implement or promote before
that review accepts the schemas, bindings, vectors, and authority boundary.
