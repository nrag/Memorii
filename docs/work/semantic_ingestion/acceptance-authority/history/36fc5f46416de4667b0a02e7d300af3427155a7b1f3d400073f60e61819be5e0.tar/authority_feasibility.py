"""Nonproduction feasibility proof for the proposed approval authority.

This local model deliberately owns its tiny CTV subset and uses a fixed test
key. It is not a CTV implementation, a trust store, or an acceptance runtime.
"""

from __future__ import annotations

import base64
import json
from dataclasses import dataclass
from hashlib import sha256
from typing import Any

from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.primitives.asymmetric.ed25519 import (
    Ed25519PrivateKey,
    Ed25519PublicKey,
)

PROFILE = "memorii.acceptance.ed25519.rfc8032.v1"
STATUS_PURPOSE = "semantic_ingestion_capability_baseline_current_status"


class AuthorityRejected(ValueError):
    """The proposed authority chain did not establish current approval."""


@dataclass(frozen=True)
class BootstrapLimits:
    max_input_bytes: int
    max_ctv_depth: int
    max_ctv_nodes: int


@dataclass(frozen=True)
class EffectiveLimits:
    max_input_bytes: int
    max_ctv_depth: int
    max_ctv_nodes: int


@dataclass(frozen=True)
class SignedBody:
    purpose: str
    body: dict[str, Any]
    digest: str
    signature: str


@dataclass(frozen=True)
class UnsignedPointer:
    body: dict[str, Any]
    digest: str


def _json_string_bytes(value: str) -> bytes:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":")).encode("utf-8")


def _ctv(value: Any) -> bytes:
    """Closed CTV subset using SIA encoded UTF-8 JSON-string map ordering."""
    if value is None:
        return b"null"
    if type(value) is bool:
        return b"true" if value else b"false"
    if type(value) is int:
        return b'{"$type":"integer","value":"' + str(value).encode("ascii") + b'"}'
    if type(value) is str:
        return _json_string_bytes(value)
    if type(value) is bytes:
        return b'{"$type":"bytes","value":"' + base64.b64encode(value) + b'"}'
    if type(value) in (list, tuple):
        tag = b"list" if type(value) is list else b"tuple"
        return (
            b'{"$type":"'
            + tag
            + b'","items":['
            + b",".join(_ctv(item) for item in value)
            + b"]}"
        )
    if type(value) is dict and all(type(key) is str for key in value):
        entries = sorted(value.items(), key=lambda item: _json_string_bytes(item[0]))
        return (
            b'{"$type":"map","entries":['
            + b",".join(
                b"[" + _ctv(key) + b"," + _ctv(item) + b"]" for key, item in entries
            )
            + b"]}"
        )
    raise AuthorityRejected("ctv_value")


def _lp(*parts: bytes) -> bytes:
    return b"".join(len(part).to_bytes(8, "big") + part for part in parts)


def _digest(domain: str, body: dict[str, Any]) -> str:
    return sha256(_lp(domain.encode("ascii"), _ctv(body))).hexdigest()


def _message(purpose: str, body: dict[str, Any], digest: str) -> bytes:
    return _ctv({"purpose": purpose, "unsigned_content": _ctv(body), "digest": digest})


def _sign(
    purpose: str, domain: str, body: dict[str, Any], signer: Ed25519PrivateKey
) -> SignedBody:
    digest = _digest(domain, body)
    signature = base64.b64encode(signer.sign(_message(purpose, body, digest))).decode(
        "ascii"
    )
    return SignedBody(purpose, body, digest, signature)


def _verify(
    signed: SignedBody, domain: str, purpose: str, public_key: Ed25519PublicKey
) -> None:
    if signed.purpose != purpose or _digest(domain, signed.body) != signed.digest:
        raise AuthorityRejected("signed_body")
    try:
        raw = base64.b64decode(signed.signature, validate=True)
        if len(raw) != 64 or base64.b64encode(raw).decode("ascii") != signed.signature:
            raise AuthorityRejected("signature")
        public_key.verify(raw, _message(purpose, signed.body, signed.digest))
    except (InvalidSignature, ValueError) as exc:
        raise AuthorityRejected("signature") from exc


def bounded_json(raw: bytes, limits: BootstrapLimits) -> dict[str, Any]:
    """Apply protected bootstrap byte ceilings before invoking a decoder."""
    if len(raw) > limits.max_input_bytes:
        raise AuthorityRejected("bootstrap_limit")
    parsed = json.loads(raw)
    if type(parsed) is not dict:
        raise AuthorityRejected("json_object")
    return parsed


def validate_effective_limits(
    bootstrap: BootstrapLimits, effective: EffectiveLimits
) -> None:
    if (
        min(effective.max_input_bytes, effective.max_ctv_depth, effective.max_ctv_nodes)
        <= 0
    ):
        raise AuthorityRejected("effective_limit")
    if (
        effective.max_input_bytes > bootstrap.max_input_bytes
        or effective.max_ctv_depth > bootstrap.max_ctv_depth
        or effective.max_ctv_nodes > bootstrap.max_ctv_nodes
    ):
        raise AuthorityRejected("effective_limit_expansion")


def issuance_snapshot(signer: Ed25519PrivateKey) -> SignedBody:
    return _sign(
        "snapshot",
        "memorii:sia-capability-baseline-approval-issuance-trust-snapshot:v1\\0",
        {
            "authority_id": "test-authority",
            "snapshot_sequence": 1,
            "limits_digest": "limits",
            "initial_key_state_digest": None,
        },
        signer,
    )


def release(
    snapshot: SignedBody,
    name: str,
    signer: Ed25519PrivateKey,
    issuance_sequence: int = 1,
) -> SignedBody:
    return _sign(
        "approval",
        "memorii:sia-capability-baseline-approval-release:v1\\0",
        {
            "release_name": name,
            "issuance_trust_snapshot_digest": snapshot.digest,
            "acceptance_release_epoch": 1,
            "acceptance_release_sequence": issuance_sequence,
        },
        signer,
    )


def key_state_record(
    snapshot: SignedBody,
    predecessor: SignedBody | None,
    state: str,
    sequence: int,
    signer: Ed25519PrivateKey,
    key_reference: str = "test-key",
) -> SignedBody:
    if state not in {"active", "retired", "revoked", "compromised"}:
        raise AuthorityRejected("key_state")
    return _sign(
        "key_state",
        "memorii:sia-capability-baseline-approval-key-status:v1\\0",
        {
            "key_reference": key_reference,
            "state": state,
            "key_state_sequence": sequence,
            "predecessor_key_state_digest": None
            if predecessor is None
            else predecessor.digest,
            "issuance_trust_snapshot_digest": snapshot.digest,
        },
        signer,
    )


def lifecycle_record(
    snapshot: SignedBody,
    release_body: SignedBody,
    predecessor: SignedBody | None,
    transition: str,
    effective_epoch: int,
    effective_sequence: int,
    signer: Ed25519PrivateKey,
) -> SignedBody:
    if transition not in {
        "activate_genesis",
        "activate_successor",
        "revoke",
        "compromise",
    }:
        raise AuthorityRejected("transition")
    prior_subject = (
        None if predecessor is None else predecessor.body["subject_release_digest"]
    )
    prior_active = None if transition == "activate_genesis" else prior_subject
    return _sign(
        "lifecycle",
        "memorii:sia-capability-baseline-approval-lifecycle:v1\\0",
        {
            "subject_release_digest": release_body.digest,
            "issuance_trust_snapshot_digest": snapshot.digest,
            "predecessor_record_digest": None
            if predecessor is None
            else predecessor.digest,
            "record_sequence": 1
            if predecessor is None
            else predecessor.body["record_sequence"] + 1,
            "transition": transition,
            "effective_lifecycle_epoch": effective_epoch,
            "effective_lifecycle_sequence": effective_sequence,
            "prior_active_release_digest": prior_active,
            "successor_release_digest": (
                release_body.digest if transition == "activate_successor" else None
            ),
            "revoked_at": "2026-09-06T00:00:00.000000Z"
            if transition in {"revoke", "compromise"}
            else None,
            "compromise_effective_at": "2026-09-06T00:00:00.000000Z"
            if transition == "compromise"
            else None,
        },
        signer,
    )


def active_pointer(record: SignedBody, release_body: SignedBody) -> UnsignedPointer:
    body = {
        "release_digest": release_body.digest,
        "lifecycle_head_digest": record.digest,
        "acceptance_release_epoch": release_body.body["acceptance_release_epoch"],
        "acceptance_release_sequence": release_body.body["acceptance_release_sequence"],
    }
    return UnsignedPointer(
        body,
        _digest("memorii:sia-capability-baseline-approval-active-pointer:v1\\0", body),
    )


def current_checkpoint(
    pointer: UnsignedPointer | None,
    record: SignedBody,
    key_head: SignedBody,
    generation: int,
    signer: Ed25519PrivateKey,
) -> SignedBody:
    active = (
        (None, None, None)
        if pointer is None
        else (
            pointer.digest,
            pointer.body["acceptance_release_epoch"],
            pointer.body["acceptance_release_sequence"],
        )
    )
    return _sign(
        STATUS_PURPOSE,
        "memorii:sia-capability-baseline-approval-status-checkpoint:v1\\0",
        {
            "status_generation": generation,
            "lifecycle_head_digest": record.digest,
            "lifecycle_head_sequence": record.body["record_sequence"],
            "current_key_state_head_digest": key_head.digest,
            "current_key_state_sequence": key_head.body["key_state_sequence"],
            "active_pointer_digest": active[0],
            "active_release_epoch": active[1],
            "active_release_sequence": active[2],
            "status_signer": {
                "key_reference": "test-status-key",
                "signature_profile_id": PROFILE,
                "purpose": STATUS_PURPOSE,
            },
        },
        signer,
    )


@dataclass
class InMemoryCurrentStatusProvider:
    checkpoint: SignedBody

    def load_current(self) -> SignedBody:
        return self.checkpoint


def dependency_dag(
    snapshot: SignedBody,
    release_body: SignedBody,
    record: SignedBody,
    pointer: UnsignedPointer,
    key_head: SignedBody,
    checkpoint: SignedBody,
) -> dict[str, tuple[str, ...]]:
    return {
        snapshot.digest: (),
        release_body.digest: (snapshot.digest,),
        record.digest: (snapshot.digest, release_body.digest),
        pointer.digest: (record.digest, release_body.digest),
        key_head.digest: (),
        checkpoint.digest: (record.digest, pointer.digest, key_head.digest),
    }


def _replay_key_state(
    records: tuple[SignedBody, ...],
    expected_head: SignedBody,
    snapshot: SignedBody,
    public_key: Ed25519PublicKey,
) -> None:
    if not records or records[-1].digest != expected_head.digest:
        raise AuthorityRejected("current_key_head")
    predecessor: str | None = None
    prior_state: str | None = None
    for sequence, record in enumerate(records, start=1):
        _verify(
            record,
            "memorii:sia-capability-baseline-approval-key-status:v1\\0",
            "key_state",
            public_key,
        )
        if (
            record.body["key_state_sequence"] != sequence
            or record.body["predecessor_key_state_digest"] != predecessor
            or record.body["issuance_trust_snapshot_digest"] != snapshot.digest
        ):
            raise AuthorityRejected("key_state_replay")
        if record.body["key_reference"] != "test-key":
            raise AuthorityRejected("key_state_rotation")
        allowed = {
            None: {"active"},
            "active": {"retired", "revoked", "compromised"},
            "retired": {"revoked", "compromised"},
            "revoked": set(),
            "compromised": set(),
        }
        if record.body["state"] not in allowed[prior_state]:
            raise AuthorityRejected("key_state_transition")
        predecessor = record.digest
        prior_state = record.body["state"]
    if records[-1].body["state"] != "active":
        raise AuthorityRejected("key_not_active")


def _replay_lifecycle(
    records: tuple[SignedBody, ...], snapshot: SignedBody, public_key: Ed25519PublicKey
) -> None:
    predecessor: str | None = None
    prior: SignedBody | None = None
    for sequence, record in enumerate(records, start=1):
        _verify(
            record,
            "memorii:sia-capability-baseline-approval-lifecycle:v1\\0",
            "lifecycle",
            public_key,
        )
        body = record.body
        if (
            body["record_sequence"] != sequence
            or body["predecessor_record_digest"] != predecessor
            or body["issuance_trust_snapshot_digest"] != snapshot.digest
            or body["effective_lifecycle_sequence"] != sequence
        ):
            raise AuthorityRejected("lifecycle_replay")
        transition = body["transition"]
        if transition == "activate_genesis":
            if (
                sequence != 1
                or body["prior_active_release_digest"] is not None
                or body["successor_release_digest"] is not None
                or body["revoked_at"] is not None
                or body["compromise_effective_at"] is not None
            ):
                raise AuthorityRejected("lifecycle_genesis")
        elif transition == "activate_successor":
            if (
                prior is None
                or body["prior_active_release_digest"]
                != prior.body["subject_release_digest"]
                or body["successor_release_digest"] != body["subject_release_digest"]
                or body["revoked_at"] is not None
                or body["compromise_effective_at"] is not None
            ):
                raise AuthorityRejected("lifecycle_successor")
        elif transition == "revoke":
            if (
                prior is None
                or body["revoked_at"] is None
                or body["compromise_effective_at"] is not None
                or body["successor_release_digest"] is not None
            ):
                raise AuthorityRejected("lifecycle_revoke")
        elif transition == "compromise":
            if (
                prior is None
                or body["revoked_at"] is None
                or body["compromise_effective_at"] is None
                or body["successor_release_digest"] is not None
            ):
                raise AuthorityRejected("lifecycle_compromise")
        else:
            raise AuthorityRejected("transition")
        predecessor = record.digest
        prior = record


def verify_current_release(
    candidate: SignedBody,
    snapshot: SignedBody,
    records: tuple[SignedBody, ...],
    pointers: tuple[UnsignedPointer, ...],
    key_records: tuple[SignedBody, ...],
    status_provider: InMemoryCurrentStatusProvider,
    public_key: Ed25519PublicKey,
) -> None:
    _verify(
        snapshot,
        "memorii:sia-capability-baseline-approval-issuance-trust-snapshot:v1\\0",
        "snapshot",
        public_key,
    )
    _verify(
        candidate,
        "memorii:sia-capability-baseline-approval-release:v1\\0",
        "approval",
        public_key,
    )
    if candidate.body["issuance_trust_snapshot_digest"] != snapshot.digest:
        raise AuthorityRejected("issuance_snapshot")
    checkpoint = status_provider.load_current()
    _verify(
        checkpoint,
        "memorii:sia-capability-baseline-approval-status-checkpoint:v1\\0",
        STATUS_PURPOSE,
        public_key,
    )
    if checkpoint.body["status_signer"] != {
        "key_reference": "test-status-key",
        "signature_profile_id": PROFILE,
        "purpose": STATUS_PURPOSE,
    }:
        raise AuthorityRejected("status_signer")
    active = (
        checkpoint.body["active_pointer_digest"],
        checkpoint.body["active_release_epoch"],
        checkpoint.body["active_release_sequence"],
    )
    if any(item is None for item in active) and any(
        item is not None for item in active
    ):
        raise AuthorityRejected("active_coordinate_nullability")
    by_record = {record.digest: record for record in records}
    head = by_record.get(checkpoint.body["lifecycle_head_digest"])
    if (
        head is None
        or head.body["record_sequence"] != checkpoint.body["lifecycle_head_sequence"]
    ):
        raise AuthorityRejected("lifecycle_head")
    _replay_lifecycle(records, snapshot, public_key)
    key_head = next(
        (
            item
            for item in key_records
            if item.digest == checkpoint.body["current_key_state_head_digest"]
        ),
        None,
    )
    if (
        key_head is None
        or key_head.body["key_state_sequence"]
        != checkpoint.body["current_key_state_sequence"]
    ):
        raise AuthorityRejected("current_key_head")
    _replay_key_state(key_records, key_head, snapshot, public_key)
    if active == (None, None, None):
        raise AuthorityRejected("not_current")
    pointer = next((item for item in pointers if item.digest == active[0]), None)
    if (
        pointer is None
        or _digest(
            "memorii:sia-capability-baseline-approval-active-pointer:v1\\0",
            pointer.body,
        )
        != pointer.digest
    ):
        raise AuthorityRejected("current_pointer_digest")
    if pointer.body["lifecycle_head_digest"] != head.digest:
        raise AuthorityRejected("current_pointer")
    if (
        pointer.body["acceptance_release_epoch"],
        pointer.body["acceptance_release_sequence"],
    ) != active[1:]:
        raise AuthorityRejected("active_coordinates")
    if pointer.body["release_digest"] != candidate.digest:
        raise AuthorityRejected("not_current")
