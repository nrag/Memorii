"""Scoped proofs for the proposed, nonproduction approval authority."""

# pyright: reportMissingImports=false
# Pyright does not add this un-packaged WorkPlan directory to its import roots.

import pytest
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

from authority_feasibility import (
    AuthorityRejected,
    BootstrapLimits,
    EffectiveLimits,
    InMemoryCurrentStatusProvider,
    STATUS_PURPOSE,
    SignedBody,
    UnsignedPointer,
    _ctv,
    _sign,
    active_pointer,
    bounded_json,
    current_checkpoint,
    dependency_dag,
    issuance_snapshot,
    key_state_record,
    lifecycle_record,
    release,
    validate_effective_limits,
    verify_current_release,
)


CHECKPOINT_DOMAIN = "memorii:sia-capability-baseline-approval-status-checkpoint:v1\\0"
LIFECYCLE_DOMAIN = "memorii:sia-capability-baseline-approval-lifecycle:v1\\0"


def _resign_checkpoint(body: dict, signer: Ed25519PrivateKey) -> SignedBody:
    return _sign(STATUS_PURPOSE, CHECKPOINT_DOMAIN, body, signer)


def _resign_lifecycle(body: dict, signer: Ed25519PrivateKey) -> SignedBody:
    return _sign("lifecycle", LIFECYCLE_DOMAIN, body, signer)


def _chain():
    signer = Ed25519PrivateKey.from_private_bytes(bytes.fromhex("00" * 31 + "01"))
    snapshot = issuance_snapshot(signer)
    first = release(snapshot, "first", signer)
    first_record = lifecycle_record(
        snapshot, first, None, "activate_genesis", 1, 1, signer
    )
    first_pointer = active_pointer(first_record, first)
    second = release(snapshot, "second", signer, 2)
    second_record = lifecycle_record(
        snapshot, second, first_record, "activate_successor", 2, 2, signer
    )
    second_pointer = active_pointer(second_record, second)
    key_active = key_state_record(snapshot, None, "active", 1, signer)
    checkpoint = current_checkpoint(
        second_pointer, second_record, key_active, 2, signer
    )
    return (
        signer,
        snapshot,
        first,
        first_record,
        first_pointer,
        second,
        second_record,
        second_pointer,
        key_active,
        checkpoint,
    )


def test_acyclic_current_head_and_unsigned_pointer() -> None:
    (
        signer,
        snapshot,
        first,
        first_record,
        first_pointer,
        second,
        second_record,
        second_pointer,
        key,
        checkpoint,
    ) = _chain()
    dag = dependency_dag(
        snapshot, second, second_record, second_pointer, key, checkpoint
    )
    assert all(
        dep not in dag or dep in tuple(dag)[:index]
        for index, deps in enumerate(dag.values())
        for dep in deps
    )
    assert not hasattr(second_pointer, "signature")
    verify_current_release(
        second,
        snapshot,
        (first_record, second_record),
        (first_pointer, second_pointer),
        (key,),
        InMemoryCurrentStatusProvider(checkpoint),
        signer.public_key(),
    )
    with pytest.raises(AuthorityRejected, match="not_current"):
        verify_current_release(
            first,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (key,),
            InMemoryCurrentStatusProvider(checkpoint),
            signer.public_key(),
        )


def test_checkpoint_authenticates_full_status_signer_and_active_coordinates() -> None:
    (
        signer,
        snapshot,
        _,
        first_record,
        first_pointer,
        second,
        second_record,
        second_pointer,
        key,
        checkpoint,
    ) = _chain()
    body = dict(checkpoint.body)
    body["status_signer"] = {
        "key_reference": "test-status-key",
        "signature_profile_id": "wrong",
        "purpose": STATUS_PURPOSE,
    }
    forged = _resign_checkpoint(body, signer)
    with pytest.raises(AuthorityRejected, match="status_signer"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (key,),
            InMemoryCurrentStatusProvider(forged),
            signer.public_key(),
        )
    body = dict(checkpoint.body)
    body["active_release_sequence"] = None
    malformed = _resign_checkpoint(body, signer)
    with pytest.raises(AuthorityRejected, match="active_coordinate_nullability"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (key,),
            InMemoryCurrentStatusProvider(malformed),
            signer.public_key(),
        )

    all_null = current_checkpoint(None, second_record, key, 3, signer)
    with pytest.raises(AuthorityRejected, match="not_current"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (key,),
            InMemoryCurrentStatusProvider(all_null),
            signer.public_key(),
        )

    altered = UnsignedPointer(
        {**second_pointer.body, "release_digest": snapshot.digest},
        second_pointer.digest,
    )
    with pytest.raises(AuthorityRejected, match="current_pointer_digest"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, altered),
            (key,),
            InMemoryCurrentStatusProvider(checkpoint),
            signer.public_key(),
        )


def test_current_trust_head_blocks_old_unexpired_key_prefix() -> None:
    (
        signer,
        snapshot,
        _,
        first_record,
        first_pointer,
        second,
        second_record,
        second_pointer,
        active_key,
        _,
    ) = _chain()
    revoked = key_state_record(snapshot, active_key, "revoked", 2, signer)
    current = current_checkpoint(second_pointer, second_record, revoked, 3, signer)
    with pytest.raises(AuthorityRejected, match="key_not_active"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (active_key, revoked),
            InMemoryCurrentStatusProvider(current),
            signer.public_key(),
        )

    revived = key_state_record(snapshot, revoked, "active", 3, signer)
    revival_checkpoint = current_checkpoint(
        second_pointer, second_record, revived, 4, signer
    )
    with pytest.raises(AuthorityRejected, match="key_state_transition"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (active_key, revoked, revived),
            InMemoryCurrentStatusProvider(revival_checkpoint),
            signer.public_key(),
        )

    retired = key_state_record(snapshot, active_key, "retired", 2, signer)
    retired_checkpoint = current_checkpoint(
        second_pointer, second_record, retired, 4, signer
    )
    with pytest.raises(AuthorityRejected, match="key_not_active"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (active_key, retired),
            InMemoryCurrentStatusProvider(retired_checkpoint),
            signer.public_key(),
        )

    compromised = key_state_record(snapshot, active_key, "compromised", 2, signer)
    compromised_checkpoint = current_checkpoint(
        second_pointer, second_record, compromised, 4, signer
    )
    with pytest.raises(AuthorityRejected, match="key_not_active"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (active_key, compromised),
            InMemoryCurrentStatusProvider(compromised_checkpoint),
            signer.public_key(),
        )

    rotated = key_state_record(snapshot, active_key, "retired", 2, signer, "other-key")
    rotated_checkpoint = current_checkpoint(
        second_pointer, second_record, rotated, 4, signer
    )
    with pytest.raises(AuthorityRejected, match="key_state_rotation"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (active_key, rotated),
            InMemoryCurrentStatusProvider(rotated_checkpoint),
            signer.public_key(),
        )
    with pytest.raises(AuthorityRejected, match="current_key_head"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record),
            (first_pointer, second_pointer),
            (active_key,),
            InMemoryCurrentStatusProvider(current),
            signer.public_key(),
        )


def test_issuance_and_effective_lifecycle_counters_are_distinct() -> None:
    signer, snapshot, _, _, _, second, second_record, _, _, _ = _chain()
    assert second.body["acceptance_release_sequence"] == 2
    assert second_record.body["effective_lifecycle_sequence"] == 2
    revoke = lifecycle_record(snapshot, second, second_record, "revoke", 3, 3, signer)
    assert revoke.body["subject_release_digest"] == second.digest
    assert second.body["acceptance_release_sequence"] == 2
    assert revoke.body["effective_lifecycle_sequence"] == 3


def test_lifecycle_transition_fields_reject_under_a_valid_signature() -> None:
    signer, snapshot, _, first_record, _, second, second_record, _, _, _ = _chain()
    bad_genesis = dict(first_record.body)
    bad_genesis["successor_release_digest"] = first_record.body[
        "subject_release_digest"
    ]
    checkpoint_key = key_state_record(snapshot, None, "active", 1, signer)
    checkpoint = current_checkpoint(None, second_record, checkpoint_key, 3, signer)
    with pytest.raises(AuthorityRejected, match="lifecycle_genesis"):
        verify_current_release(
            second,
            snapshot,
            (_resign_lifecycle(bad_genesis, signer), second_record),
            (),
            (checkpoint_key,),
            InMemoryCurrentStatusProvider(checkpoint),
            signer.public_key(),
        )

    bad_successor = dict(second_record.body)
    bad_successor["successor_release_digest"] = None
    resigned_successor = _resign_lifecycle(bad_successor, signer)
    checkpoint = current_checkpoint(None, resigned_successor, checkpoint_key, 3, signer)
    with pytest.raises(AuthorityRejected, match="lifecycle_successor"):
        verify_current_release(
            second,
            snapshot,
            (first_record, resigned_successor),
            (),
            (checkpoint_key,),
            InMemoryCurrentStatusProvider(checkpoint),
            signer.public_key(),
        )

    revoke = lifecycle_record(snapshot, second, second_record, "revoke", 3, 3, signer)
    bad_revoke = dict(revoke.body)
    bad_revoke["revoked_at"] = None
    resigned_revoke = _resign_lifecycle(bad_revoke, signer)
    checkpoint = current_checkpoint(None, resigned_revoke, checkpoint_key, 4, signer)
    with pytest.raises(AuthorityRejected, match="lifecycle_revoke"):
        verify_current_release(
            second,
            snapshot,
            (first_record, second_record, resigned_revoke),
            (),
            (checkpoint_key,),
            InMemoryCurrentStatusProvider(checkpoint),
            signer.public_key(),
        )


def test_ctv_uses_encoded_json_string_bytes_for_map_order() -> None:
    encoded = _ctv({"\n": 1, "A": 2})
    assert encoded.index(b'"A"') < encoded.index(b'"\\n"')
    assert _ctv({"z": 1, "a": 2}) == _ctv({"a": 2, "z": 1})
    nested = _ctv({"outer": {"\n": 1, "A": 2}})
    assert nested.index(b'"A"') < nested.index(b'"\\n"')


def test_bootstrap_limits_precede_decode_and_effective_limits_only_narrow() -> None:
    bootstrap = BootstrapLimits(16, 3, 8)
    with pytest.raises(AuthorityRejected, match="bootstrap_limit"):
        bounded_json(b'{"too_long": true}', bootstrap)
    assert bounded_json(b'{"ok":1}', bootstrap) == {"ok": 1}
    validate_effective_limits(bootstrap, EffectiveLimits(8, 2, 7))
    with pytest.raises(AuthorityRejected, match="effective_limit_expansion"):
        validate_effective_limits(bootstrap, EffectiveLimits(17, 2, 7))
